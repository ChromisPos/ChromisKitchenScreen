#!/bin/sh

DIRNAME=`dirname $0`
CP=$DIRNAME/KitchenScr.jar


java -cp $CP uk.chromis.kitchenscr.KitchenScr
sudo poweroff